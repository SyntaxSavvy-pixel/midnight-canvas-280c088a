// Complete Chrome Extension Pro Feature System
// Add this to your main popup.js or create a separate pro-manager.js

// Import centralized configuration
import { CONFIG } from './config.js';

class ProManager {
  constructor() {
    this.apiBase = CONFIG.API.BASE;
    this.isPro = false;
    this.checkingStatus = false;
    this.lastStatusCheck = 0;
    this.statusCheckInterval = 5 * 60 * 1000; // 5 minutes
  }

  // Initialize Pro manager
  async init() {
    await this.loadStoredStatus();
    await this.checkProStatus();
    this.setupPeriodicCheck();
  }

  // Load Pro status from extension storage
  async loadStoredStatus() {
    try {
      const data = await chrome.storage.local.get(['proData']);
      if (data.proData) {
        this.isPro = data.proData.isPro || false;
        this.lastStatusCheck = data.proData.lastCheck || 0;
        
      }
    } catch (error) {
      
    }
  }

  // Save Pro status to extension storage
  async saveProStatus(proData) {
    try {
      await chrome.storage.local.set({
        proData: {
          ...proData,
          lastCheck: Date.now()
        }
      });
      this.isPro = proData.isPro;
      
    } catch (error) {
      
    }
  }

  // Get user identifier (email from form or stored)
  async getUserIdentifier() {
    try {
      // Try to get stored user data
      const stored = await chrome.storage.local.get(['userData', 'userEmail']);

      if (stored.userData?.email) {
        return stored.userData.email;
      }

      if (stored.userEmail) {
        return stored.userEmail;
      }

      // If no stored data, prompt user or return null
      return null;
    } catch (error) {
      
      return null;
    }
  }

  // Check Pro status with backend
  async checkProStatus(force = false) {
    try {
      // Avoid too frequent checks
      const now = Date.now();
      if (!force && (now - this.lastStatusCheck) < this.statusCheckInterval) {
        
        return this.isPro;
      }

      if (this.checkingStatus) {
        
        return this.isPro;
      }

      this.checkingStatus = true;

      const userIdentifier = await this.getUserIdentifier();
      if (!userIdentifier) {
        
        this.checkingStatus = false;
        return false;
      }

      const response = await fetch(`${this.apiBase}/check-status?email=${encodeURIComponent(userIdentifier)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        
        await this.saveProStatus({
          isPro: data.isPro,
          status: data.status,
          subscriptionId: data.subscriptionId,
          currentPeriodEnd: data.currentPeriodEnd,
          plan: data.plan
        });

        this.checkingStatus = false;
        return data.isPro;
      } else {
        
        this.checkingStatus = false;
        return this.isPro; // Return cached status
      }

    } catch (error) {
      
      this.checkingStatus = false;
      return this.isPro; // Return cached status
    }
  }

  // Create Pro upgrade checkout
  async createCheckout(email) {
    try {
      if (!email) {
        throw new Error('Email is required for checkout');
      }

      const response = await fetch(`${this.apiBase}/create-checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          userId: email
        })
      });

      if (response.ok) {
        const data = await response.json();
        
        // Store user email for future status checks
        await chrome.storage.local.set({
          userEmail: email,
          checkoutSession: {
            sessionId: data.sessionId,
            customerId: data.customerId,
            createdAt: Date.now()
          }
        });

        return data.url;
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create checkout');
      }

    } catch (error) {
      
      throw error;
    }
  }

  // Handle upgrade button click
  async handleUpgrade() {
    try {
      // Get email from user
      const email = await this.promptForEmail();
      if (!email) {
        return;
      }

      // Create checkout session
      const checkoutUrl = await this.createCheckout(email);

      // Open checkout in new tab
      await chrome.tabs.create({
        url: checkoutUrl,
        active: true
      });

      // Start monitoring for Pro activation
      this.startActivationMonitoring(email);

      this.showMessage('💳 Complete your purchase to unlock Pro features!', 'info');

    } catch (error) {
      
      this.showMessage('❌ Unable to start upgrade process. Please try again.', 'error');
    }
  }

  // Prompt user for email
  async promptForEmail() {
    return new Promise((resolve) => {
      const modal = document.createElement('div');
      modal.innerHTML = `
        <div style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;">
          <div style="background: white; padding: 24px; border-radius: 12px; max-width: 400px; width: 90%;">
            <h3 style="margin: 0 0 16px 0;">Upgrade to Pro</h3>
            <p style="margin: 0 0 16px 0; color: #666;">Enter your email to continue:</p>
            <input type="email" id="proEmail" placeholder="your@email.com" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; margin-bottom: 16px;">
            <div style="display: flex; gap: 8px;">
              <button id="confirmUpgrade" style="flex: 1; padding: 12px; background: #2563eb; color: white; border: none; border-radius: 6px; cursor: pointer;">Continue</button>
              <button id="cancelUpgrade" style="flex: 1; padding: 12px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">Cancel</button>
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(modal);

      const emailInput = modal.querySelector('#proEmail');
      const confirmBtn = modal.querySelector('#confirmUpgrade');
      const cancelBtn = modal.querySelector('#cancelUpgrade');

      emailInput.focus();

      const cleanup = () => {
        document.body.removeChild(modal);
      };

      confirmBtn.addEventListener('click', () => {
        const email = emailInput.value.trim();
        if (email && email.includes('@')) {
          cleanup();
          resolve(email);
        } else {
          emailInput.style.borderColor = '#ef4444';
          emailInput.focus();
        }
      });

      cancelBtn.addEventListener('click', () => {
        cleanup();
        resolve(null);
      });

      emailInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          confirmBtn.click();
        }
      });
    });
  }

  // Start monitoring for Pro activation after checkout
  startActivationMonitoring(email) {
    
    let attempts = 0;
    const maxAttempts = 30; // Monitor for 5 minutes
    const checkInterval = 10000; // Check every 10 seconds

    const monitor = setInterval(async () => {
      attempts++;
      
      const isNowPro = await this.checkProStatus(true);

      if (isNowPro) {
        
        clearInterval(monitor);

        this.showMessage('🎉 Pro features activated! Welcome to Pro!', 'success');
        this.onProActivated();

        // Show notification
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon-48.png',
          title: 'Welcome to Pro!',
          message: '🎉 Your Pro features are now active!'
        });

        return;
      }

      if (attempts >= maxAttempts) {
        
        clearInterval(monitor);
        this.showMessage('⏰ Please refresh the extension if your purchase completed.', 'warning');
      }
    }, checkInterval);
  }

  // Setup periodic Pro status checking
  setupPeriodicCheck() {
    // Check status every 5 minutes when extension is active
    setInterval(async () => {
      await this.checkProStatus();
    }, this.statusCheckInterval);

    // Also check when extension popup opens
    document.addEventListener('DOMContentLoaded', async () => {
      await this.checkProStatus();
    });
  }

  // Called when Pro is activated
  onProActivated() {
    // Update UI to show Pro features
    this.updateUIForPro();

    // Trigger any Pro feature initialization
    this.initProFeatures();

    // Update extension badge if you use one
    chrome.action.setBadgeText({ text: 'PRO' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  }

  // Update UI to show Pro features
  updateUIForPro() {
    // Hide upgrade buttons
    document.querySelectorAll('.upgrade-btn').forEach(btn => {
      btn.style.display = 'none';
    });

    // Show Pro features
    document.querySelectorAll('.pro-feature').forEach(feature => {
      feature.style.display = 'block';
    });

    // Remove Pro badges/locks
    document.querySelectorAll('.pro-badge').forEach(badge => {
      badge.style.display = 'none';
    });

  }

  // Initialize Pro features
  initProFeatures() {
    // Enable unlimited tabs
    this.unlimitedTabsEnabled = true;

    // Enable advanced timer features
    this.advancedTimersEnabled = true;

    // Enable bulk operations
    this.bulkOperationsEnabled = true;

  }

  // Check if user has Pro access to a feature
  hasProAccess(feature) {
    if (!this.isPro) {
      return false;
    }

    // Add specific feature checks here if needed
    switch (feature) {
      case 'unlimited_tabs':
      case 'advanced_timers':
      case 'bulk_operations':
      case 'custom_themes':
        return true;
      default:
        return false;
    }
  }

  // Show Pro upgrade prompt for locked features
  showProPrompt(feature) {
    const modal = document.createElement('div');
    modal.innerHTML = `
      <div style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;">
        <div style="background: white; padding: 24px; border-radius: 12px; max-width: 400px; width: 90%;">
          <h3 style="margin: 0 0 16px 0;">🚀 Pro Feature</h3>
          <p style="margin: 0 0 16px 0; color: #666;">This feature requires Pro access. Upgrade now to unlock:</p>
          <ul style="margin: 0 0 16px 0; padding-left: 20px; color: #666;">
            <li>Unlimited tabs and bookmarks</li>
            <li>Advanced timer controls</li>
            <li>Bulk operations</li>
            <li>Priority support</li>
          </ul>
          <div style="display: flex; gap: 8px;">
            <button id="upgradeNow" style="flex: 1; padding: 12px; background: #2563eb; color: white; border: none; border-radius: 6px; cursor: pointer;">Upgrade Now</button>
            <button id="closePro" style="flex: 1; padding: 12px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">Not Now</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#upgradeNow').addEventListener('click', () => {
      document.body.removeChild(modal);
      this.handleUpgrade();
    });

    modal.querySelector('#closePro').addEventListener('click', () => {
      document.body.removeChild(modal);
    });
  }

  // Utility method to show messages
  showMessage(message, type = 'info') {
    // Implement your message display logic here
    
  }
}

// Usage in your extension:
const proManager = new ProManager();

// Initialize when extension loads
document.addEventListener('DOMContentLoaded', async () => {
  await proManager.init();
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProManager;
}