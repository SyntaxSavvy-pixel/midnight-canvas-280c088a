# Tabmangment Extension Permissions

This document explains why each permission is required for Tabmangment to function properly.

## Required Permissions

### 🔖 **bookmarks**
**Purpose:** Bookmark management and tab preservation
**Usage:**
- Save important tabs as bookmarks before auto-closing
- Create bookmark collections for easy tab restoration
- Organize saved tabs into folders for better management
- Prevent data loss by preserving important tabs permanently
- Enable users to quickly restore previously closed tabs

**User Benefit:** Never lose important tabs again. Save tabs as bookmarks for later access.

### 🧹 **browsingData**
**Purpose:** Tab usage analytics and browser optimization
**Usage:**
- Analyze tab usage patterns to identify inactive tabs
- Provide intelligent recommendations for tab cleanup
- Clear unnecessary browsing data to improve performance
- Track domain visit frequency for analytics
- Optimize browser memory usage by identifying resource-heavy tabs

**User Benefit:** Get insights into browsing habits and optimize browser performance automatically.

### 📑 **tabs**
**Purpose:** Core tab management functionality
**Usage:**
- Access and manage all open tabs
- Close inactive or duplicate tabs
- Monitor tab activity and usage patterns
- Implement auto-closing features for unused tabs
- Priority-based tab management for free vs premium users

### ⚡ **activeTab**
**Purpose:** Current tab interaction
**Usage:**
- Identify which tab is currently active
- Apply special handling to active tabs (never auto-close)
- Provide context-aware tab management

### 💾 **storage**
**Purpose:** Save user preferences and extension data
**Usage:**
- Store user subscription status and preferences
- Save tab timers and auto-close settings
- Cache payment status and subscription data
- Remember user customizations and settings

### 🔔 **notifications**
**Purpose:** User alerts and notifications
**Usage:**
- Notify users when tabs are auto-closed
- Alert about subscription status changes
- Provide feedback on tab management actions
- Warn before performing bulk operations

## Host Permissions

### 🔗 **https://api.emailjs.com/***
**Purpose:** Email communication service
**Usage:** Send support emails and user feedback

### 💳 **https://tabmangment-extension-run.vercel.app/***
**Purpose:** Stripe payment processing and subscription management
**Usage:**
- Process premium subscription payments
- Validate subscription status
- Handle billing and payment webhooks
- Manage customer portal access

## Privacy & Security

- **No Personal Data Collection:** The extension only processes tab metadata (titles, URLs) locally
- **Secure Payment Processing:** All payments handled through industry-standard Stripe integration
- **Local Storage Only:** User data stored locally in browser, not on external servers
- **Minimal Data Access:** Only accesses data necessary for tab management features
- **Transparent Usage:** All permission usage clearly documented and justified

## Data Handling

- **Tabs Data:** Used only for management and organization, never transmitted externally
- **Bookmarks:** Managed locally through Chrome's native bookmark API
- **Browsing Data:** Analyzed locally for usage patterns, statistics kept private
- **Storage:** All user preferences and settings stored in local browser storage
- **Payment Data:** Handled securely through Stripe, no payment information stored locally

For questions about permissions or privacy, please contact support through the extension.