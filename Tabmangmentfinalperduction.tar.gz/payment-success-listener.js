// Real-time payment success detection for all users
// This script monitors for Stripe success URLs and immediately activates Pro features

// Import centralized configuration
import { CONFIG } from './config.js';

class PaymentSuccessListener {
    constructor() {
        this.init();
    }

    init() {
        console.log('🎯 Payment success listener initialized');
        this.setupTabListeners();
        this.setupStorageListener();
    }

    // Listen for tab changes to detect Stripe success pages
    setupTabListeners() {
        if (chrome.tabs && chrome.tabs.onUpdated) {
            chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
                if (changeInfo.url || (tab.url && changeInfo.status === 'complete')) {
                    await this.checkForPaymentSuccess(tab.url, tabId);
                }
            });
        }
    }

    // Listen for storage changes from other extension parts
    setupStorageListener() {
        if (chrome.storage && chrome.storage.onChanged) {
            chrome.storage.onChanged.addListener(async (changes, areaName) => {
                if (areaName === 'local') {
                    // Check for payment completion signals
                    if (changes.paymentCompleted || changes.checkoutCompleted) {
                        console.log('💳 Payment completion signal detected');
                        await this.handlePaymentCompletion();
                    }
                }
            });
        }
    }

    async checkForPaymentSuccess(url, tabId) {
        if (!url) return;

        // Check for Stripe success URLs
        const successPatterns = [
            /stripe\.com.*success/i,
            /tabmangment.*success/i,
            /vercel\.app.*success/i,
            /checkout\.stripe\.com.*success/i,
            /buy\.stripe\.com.*success/i
        ];

        const isSuccessPage = successPatterns.some(pattern => pattern.test(url));

        if (isSuccessPage) {
            console.log('🎉 Payment success page detected:', url);

            // Extract session ID if available
            const sessionMatch = url.match(/session_id=([^&]+)/);
            const sessionId = sessionMatch ? sessionMatch[1] : null;

            await this.activateProFeatures(sessionId, tabId);
        }
    }

    async activateProFeatures(sessionId, tabId) {
        try {
            console.log('🚀 Activating Pro features after payment success');

            // Get user email
            const stored = await chrome.storage.local.get(['userEmail']);
            let userEmail = stored.userEmail;

            // If no stored email, try to get it from Chrome identity
            if (!userEmail) {
                userEmail = await this.getUserEmail();
            }

            if (!userEmail) {
                console.log('⚠️ No user email found for Pro activation');
                return;
            }

            // Check subscription status with API
            const status = await this.checkSubscriptionStatus(userEmail);

            if (status.isActive && status.plan === 'pro') {
                console.log('✅ Pro subscription confirmed, activating features');

                // Update storage with Pro status
                await chrome.storage.local.set({
                    isPremium: true,
                    subscriptionActive: true,
                    planType: 'pro',
                    subscriptionType: 'monthly',
                    subscriptionId: status.subscriptionId,
                    currentPeriodEnd: new Date(status.currentPeriodEnd).getTime(),
                    nextBillingDate: new Date(status.currentPeriodEnd).getTime(),
                    proActivatedAt: Date.now(),
                    userEmail: userEmail,
                    lastStatusCheck: Date.now()
                });

                // Notify other parts of extension
                await chrome.storage.local.set({
                    proActivationSignal: Date.now()
                });

                // Show success notification
                if (chrome.notifications) {
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: 'icons/icon-48.png',
                        title: 'Welcome to Tabmangment Pro! 🎉',
                        message: 'Your Pro features are now active!'
                    });
                }

                console.log('🎉 Pro features activated successfully for:', userEmail);

                // Close the success tab after 3 seconds
                setTimeout(() => {
                    if (chrome.tabs) {
                        chrome.tabs.remove(tabId).catch(() => {
                            // Tab might already be closed
                        });
                    }
                }, 3000);

            } else {
                console.log('⏳ Subscription not yet active, will retry...');
                // Retry after 10 seconds
                setTimeout(() => {
                    this.activateProFeatures(sessionId, tabId);
                }, 10000);
            }

        } catch (error) {
            console.error('❌ Error activating Pro features:', error);
        }
    }

    async getUserEmail() {
        try {
            // Try Chrome identity API
            if (chrome.identity && chrome.identity.getAuthToken) {
                const token = await chrome.identity.getAuthToken({ interactive: false });
                if (token) {
                    const response = await fetch('https://www.googleapis.com/oauth2/v1/userinfo?access_token=' + token);
                    const data = await response.json();
                    if (data.email) {
                        await chrome.storage.local.set({ userEmail: data.email });
                        return data.email;
                    }
                }
            }
        } catch (error) {
            console.log('ℹ️ Chrome identity not available:', error.message);
        }
        return null;
    }

    async checkSubscriptionStatus(userEmail) {
        try {
            const response = await fetch(`${CONFIG.API.CHECK_STATUS}?email=${encodeURIComponent(userEmail)}`);

            if (response.ok) {
                const data = await response.json();
                return {
                    isActive: data.isPro && data.status === 'active',
                    plan: data.plan,
                    subscriptionId: data.subscriptionId,
                    currentPeriodEnd: data.currentPeriodEnd
                };
            }
        } catch (error) {
            console.error('❌ Error checking subscription status:', error);
        }

        return { isActive: false, plan: 'free' };
    }

    async handlePaymentCompletion() {
        console.log('🔄 Handling payment completion signal');

        const stored = await chrome.storage.local.get(['userEmail']);
        if (stored.userEmail) {
            await this.activateProFeatures(null, null);
        }
    }
}

// Initialize the payment success listener
if (typeof window !== 'undefined') {
    // Running in content script or popup
    new PaymentSuccessListener();
} else if (typeof chrome !== 'undefined' && chrome.runtime) {
    // Running in background script
    new PaymentSuccessListener();
}