// Content script to listen for payment success across all tabs
// This ensures ANY user can get instant Pro activation

console.log('🎧 Tabmangment payment listener active');

// Listen for BroadcastChannel messages about payment success
try {
    const paymentChannel = new BroadcastChannel('tabmangment_payment');

    paymentChannel.onmessage = async (event) => {
        if (event.data && event.data.type === 'PAYMENT_SUCCESS') {
            console.log('🎉 Payment success broadcast received:', event.data);

            try {
                // Send message to extension background/popup
                await chrome.runtime.sendMessage({
                    type: 'PAYMENT_SUCCESS_BROADCAST',
                    sessionId: event.data.sessionId,
                    email: event.data.email,
                    timestamp: event.data.timestamp
                });

                console.log('✅ Forwarded payment success to extension');

            } catch (error) {
                console.log('ℹ️ Could not forward to extension:', error.message);
            }
        }
    };

    console.log('✅ Payment broadcast listener registered');

} catch (error) {
    console.log('⚠️ BroadcastChannel not supported:', error.message);
}

// Also check localStorage periodically for payment success
let lastCheck = 0;
setInterval(() => {
    try {
        const now = Date.now();

        // Only check every 5 seconds to avoid spam
        if (now - lastCheck < 5000) return;
        lastCheck = now;

        const paymentData = localStorage.getItem('tabmangment_payment_success');
        if (paymentData) {
            const payment = JSON.parse(paymentData);

            // If payment is recent and unprocessed
            if (!payment.processed && payment.timestamp) {
                const paymentTime = new Date(payment.timestamp).getTime();
                const timeDiff = now - paymentTime;

                // If payment was within last 10 minutes
                if (timeDiff < 10 * 60 * 1000) {
                    console.log('🔍 Found unprocessed payment in localStorage:', payment);

                    // Send to extension
                    chrome.runtime.sendMessage({
                        type: 'PAYMENT_SUCCESS_STORAGE',
                        sessionId: payment.sessionId,
                        email: payment.email,
                        timestamp: payment.timestamp
                    }).then(() => {
                        // Mark as processed
                        payment.processed = true;
                        localStorage.setItem('tabmangment_payment_success', JSON.stringify(payment));
                        console.log('✅ Payment processed and marked');
                    }).catch(error => {
                        console.log('ℹ️ Extension not available:', error.message);
                    });
                }
            }
        }
    } catch (error) {
        // Silently ignore localStorage errors
    }
}, 5000);

console.log('✅ Payment storage listener active');