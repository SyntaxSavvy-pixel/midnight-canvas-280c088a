// Centralized configuration for the Chrome extension
// This file should not contain sensitive data in production

// API Base URL - current production deployment
const API_BASE_URL = 'https://tabmangment-extension-pc9fpdcm7-kavon-hicks-projects.vercel.app';

export const CONFIG = {
    // API endpoints
    API: {
        BASE: `${API_BASE_URL}/api`,
        CREATE_CHECKOUT: `${API_BASE_URL}/api/create-checkout`,
        CHECK_STATUS: `${API_BASE_URL}/api/check-status`,
        BILLING_PORTAL: `${API_BASE_URL}/api/billing-portal`,
        STRIPE_WEBHOOK: `${API_BASE_URL}/api/stripe-webhook`
    },

    // Extension settings
    EXTENSION: {
        DEFAULT_TAB_LIMIT: 10,
        TIMER_CHECK_INTERVAL: 5000, // 5 seconds
        STATUS_CHECK_INTERVAL: 300000, // 5 minutes
        CACHE_TIMEOUT: 2000 // 2 seconds
    },

    // Feature flags
    FEATURES: {
        PRO_FEATURES: true,
        BILLING_PORTAL: true,
        REAL_TIME_SYNC: true
    }
};

// For manifest.json and other static files, we'll need to update manually
export const MANIFEST_URLS = {
    HOST_PERMISSIONS: [
        "https://buy.stripe.com/*",
        `${API_BASE_URL}/*`,
        "https://api.emailjs.com/*",
        "https://billing.stripe.com/*",
        "https://www.googleapis.com/*"
    ],

    CONNECT_SRC: `'self' https://buy.stripe.com ${API_BASE_URL} https://api.emailjs.com https://billing.stripe.com`
};